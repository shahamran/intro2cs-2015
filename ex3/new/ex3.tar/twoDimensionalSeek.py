position= [0,0]
heading= 0 #I will define 4 directions: 0,90,180,270
           #for forward,right,backward,left accordingly.
FORWARD= 0
BACKWARD= 180
RIGHT= 90
LEFT= 270
turn= ""
steps= 0
END_VALUE= "end"
#loop that runs until end value is entered
while turn != END_VALUE:
    turn= input("Next turn:")
    #checks if end value is reached
    if turn == END_VALUE: continue
    #decides how to change the heading (direction)
    if turn == "right":
        heading+= RIGHT           
    elif turn == "left":
        heading+= LEFT #NOTE that it's the same as doing heading-= RIGHT

    heading%= 360  # 360=0,450=90 etc...
    steps= int(input("How many steps?"))

    #checks the direction to decide how to manipulate the position variable.
    #forward/backward: only y value is changed
    #left/right: only x value is changed
    if heading == FORWARD:
        position[1]+= steps
    elif heading == BACKWARD:
        position[1]-= steps
    elif heading == RIGHT:
        position[0]+= steps
    elif heading == LEFT:
        position[0]-= steps

gandalf_dest=["right","forward"]  
#Checks what needed to be written on the output.
if position[0] >= 0:
    gandalf_dest[0]= "right"
else:
    gandalf_dest[0]= "left"

if position[1] >= 0:
    gandalf_dest[1]= "forward"
else:
    gandalf_dest[1]= "backward"

#changes the output to a positive number.
position[0]= abs(position[0])
position[1]= abs(position[1]) 
   
print("Gandalf should fly", position[0], "steps", gandalf_dest[0],\
                    "and" , position[1], "steps", gandalf_dest[1])     
