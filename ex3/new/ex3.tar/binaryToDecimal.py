num_in= int(input("Insert number in binary representation:"))
#targest_base and source_base
FROM_BASE= 2
TO_BASE= 10

num_out= 0
stop= False
pos= 0 #holds the number of digit in the composed number
       #we are currently checking.

#a loop that goes through every figure in the input number
#to convert it to chosen base (decimal in this case)
while stop == False:
    if num_in // TO_BASE == 0: stop= True #finish iteration, then stop if
                                          #there are no more figures to check
    num_out+= (num_in % TO_BASE) * (FROM_BASE ** pos)
    num_in//= TO_BASE
    pos+= 1
        
print("The decimal value of the inserted binary number is", num_out)
