bag= 0
item= 0
GANDALF_MAX= 100
STOP_VALUE= -1    #the ring (my precious)

print("Insert weights one by one:")

#reads the input until a threshold or stop value is reached
while item != STOP_VALUE:
    item= int(input())
    #the stop value is the 'ring' and it's weight is -1
    if item == STOP_VALUE:
        continue

    elif item < 0:            #invalid input, prints error and continues
        print("Weights must be non-negative")
    
    else:                     #correct input, sums the weight
        bag+= item
        if bag > GANDALF_MAX: #checks if the threshold is reached
            print("Overweight! Gandalf will not approve.")
            break   
       
#this is reached when the stop value is entered
else:
    print("The total packed weight is", bag)
