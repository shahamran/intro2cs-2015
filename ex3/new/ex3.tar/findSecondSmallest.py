smallest= 0
smallest_pos= 0
second= 0
second_pos= 0     #this will be Pippin's position
NUM_OF_DANCERS= 10
dancers= range(NUM_OF_DANCERS)

#Loop that checks the age of each dancer and sorts.
for dancer in dancers:
    #Gets the age for each dancer (from input)
    age= int(input("What is the age of the current dancer?"))

    #Checks if current dancer is smaller then the smallest so far
    if age < smallest or smallest == 0: #or if it's the first run.
        second= smallest                #'second' gets the old 'smallest' values
        second_pos= smallest_pos
        smallest= age
        smallest_pos= dancer + 1

    #If not, Checks if it's the second smallest (or first run).
    elif age < second or second == 0:
        second= age
        second_pos= dancer + 1


#prints the output
print("Pippin is dancer number", second_pos)


